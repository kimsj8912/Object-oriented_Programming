package kr.ac.kookmin.cs;

/**
    This class produces x and y.
*/

public class PPoint {
    int xA;
    int yA;

/**
    This method allocates x and y to xA and yA.
    @param x integer to assign xA.
    @param y integer to assign yA.
*/

    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };

/**
    This method gets a value of xA.
    @return xA
*/

    public int getX() {
        return xA;
    }

/**
    This method gets a value of yA.
    @return yA
*/

    public int getY() {
        return yA;
    }
}
