// ****************************************************************
// Factorials.java
//
// Reads integers from the user and prints the factorial of each.
// 
// The factorial method can throw IllegalArgumentException.
//          
// ****************************************************************

import java.util.Scanner;

public class Factorials
{
    public static void main(String[] args) throws IllegalArgumentException
    {
	char keepGoing = 'y';
	Scanner scanner = new Scanner(System.in);
	
	// ���� �Է� ���� ó���� ���� problem ����
	IllegalArgumentException negativeProblem = new IllegalArgumentException("The input is negative.");
	IllegalArgumentException overflowProblem = new IllegalArgumentException("The input is too big.");

	while (keepGoing == 'y' || keepGoing == 'Y')
	    {
		System.out.print("Enter an integer: ");
		int val = scanner.nextInt();
		try { // ���� ó�� ���Ŀ��� ���α׷��� ������� �ʵ��� try-catch�� Ȱ��
		    if (val < 0 | val > 16)
			    throw negativeProblem;
		    System.out.println("Factorial(" + val + ") = " 
					   + MathUtils.factorial(val));
		} catch (IllegalArgumentException e) {
			if (val < 0)
				System.out.println(negativeProblem);
		    else if (val > 16)
		    	System.out.println(overflowProblem);
		}
		System.out.print("Another factorial? (y/n) ");
		keepGoing = scanner.next().charAt(0);
	    }
	
	scanner.close();
    }
}
